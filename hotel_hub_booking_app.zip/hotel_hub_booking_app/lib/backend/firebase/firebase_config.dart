import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAKtAX--_33AL3OKFsi8j6oifd5XqGeaVw",
            authDomain: "hotelhub-b01d0.firebaseapp.com",
            projectId: "hotelhub-b01d0",
            storageBucket: "hotelhub-b01d0.appspot.com",
            messagingSenderId: "960096442927",
            appId: "1:960096442927:web:380fb193a403439235c4da",
            measurementId: "G-YZ2TBZLDNY"));
  } else {
    await Firebase.initializeApp();
  }
}
