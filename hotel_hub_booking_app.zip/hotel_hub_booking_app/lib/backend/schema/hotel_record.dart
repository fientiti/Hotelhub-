import 'dart:async';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class HotelRecord extends FirestoreRecord {
  HotelRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "hotelName" field.
  String? _hotelName;
  String get hotelName => _hotelName ?? '';
  bool hasHotelName() => _hotelName != null;

  // "price" field.
  int? _price;
  int get price => _price ?? 0;
  bool hasPrice() => _price != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "book" field.
  bool? _book;
  bool get book => _book ?? false;
  bool hasBook() => _book != null;

  void _initializeFields() {
    _hotelName = snapshotData['hotelName'] as String?;
    _price = snapshotData['price'] as int?;
    _location = snapshotData['location'] as String?;
    _book = snapshotData['book'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Hotel');

  static Stream<HotelRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => HotelRecord.fromSnapshot(s));

  static Future<HotelRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => HotelRecord.fromSnapshot(s));

  static HotelRecord fromSnapshot(DocumentSnapshot snapshot) => HotelRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static HotelRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      HotelRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'HotelRecord(reference: ${reference.path}, data: $snapshotData)';
}

Map<String, dynamic> createHotelRecordData({
  String? hotelName,
  int? price,
  String? location,
  bool? book,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'hotelName': hotelName,
      'price': price,
      'location': location,
      'book': book,
    }.withoutNulls,
  );

  return firestoreData;
}
