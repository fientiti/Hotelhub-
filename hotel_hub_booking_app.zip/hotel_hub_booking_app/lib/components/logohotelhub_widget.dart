import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'logohotelhub_model.dart';
export 'logohotelhub_model.dart';

class LogohotelhubWidget extends StatefulWidget {
  const LogohotelhubWidget({Key? key}) : super(key: key);

  @override
  _LogohotelhubWidgetState createState() => _LogohotelhubWidgetState();
}

class _LogohotelhubWidgetState extends State<LogohotelhubWidget> {
  late LogohotelhubModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => LogohotelhubModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Align(
          alignment: AlignmentDirectional(1.0, 1.0),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 5.0, 0.0),
            child: Container(
              width: 10.0,
              height: 10.0,
              decoration: BoxDecoration(
                color: Color(0xFF03A3FF),
                shape: BoxShape.circle,
              ),
              alignment: AlignmentDirectional(1.0, 1.0),
            ),
          ),
        ),
        Text(
          'Hotelhub',
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                fontFamily: 'Brazila',
                color: Colors.black,
                fontSize: 30.0,
                fontWeight: FontWeight.normal,
                useGoogleFonts: false,
              ),
        ),
      ],
    );
  }
}
