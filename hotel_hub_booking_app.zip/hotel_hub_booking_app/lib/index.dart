// Export pages
export '/splash/splash_widget.dart' show SplashWidget;
export '/home/home_widget.dart' show HomeWidget;
export '/details/details_widget.dart' show DetailsWidget;
